# Visual Scripting Custom Nodes Library

This library is a collection of visual script custom nodes that anyone can use in there projects.

So as to make the **Visual Scripting WorkFlow** in Godot easier to use.

![EXAMPLE](https://i.imgur.com/rws1bBY.png)
                      HERE are some basic nodes from the library.




-------


### Follow me at: [Twitter: @steincodes](https://www.twitter.com/Steincodes) and Find Tutorials about this at [Youtube:Steincodes](https://www.youtube.com/c/steincodes)


------



## Steps for using the Library

To use the custom nodes in this library all you have to do is copy the `addons` folder from this repo to your project and `paste it there`.

Then just goto the `Project Setting` and then in `Plugins tab` and set the `Plugin("VisualScript Library") to Active`.

![Project Settings Window](https://i.imgur.com/V6Mh7hA.png)


## What can you do to help

I would have loved to ask for donation or something, but for now lets keep it at why not create some more nodes just for practice learn from my GetInput Node it's got good amount of comments you should be able to figure things out on your own for help PM me on @steincodes on Twitter and follow me there for more updates on the project.

Keep track in the Project Board of any updates and plans before starting something.
